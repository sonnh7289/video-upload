from flask import Flask, render_template, request, send_from_directory, redirect, url_for
import os
from werkzeug.utils import secure_filename

#upload
app = Flask(__name__)

upload_folder = os.path.join('static', 'uploads')

app.config['UPLOAD'] = upload_folder

@app.route('/name', methods = ['GET', 'POST'])
def upload_file_0():  
    if request.method == 'POST':
        file = request.files['img'] #'img' là tên của trường file input trong biểu mẫu HTML.
        filename = secure_filename(file.filename)  
        file.save(os.path.join(app.config['UPLOAD'], filename))
        img = os.path.join(app.config['UPLOAD'], filename)
        return render_template('image_render.html', img=img)
    return render_template('image_render.html')

#upload with send_from_directory
upload = '/home/hieu/Flask/flask_dir/static/uploads/'

app.config['UPLOAD'] = upload

@app.route('/tt', methods=['GET', 'POST'])
def file_upload():
    if request.method == 'POST':
        f = request.files['file']
        filename = secure_filename(f.filename)
        f.save(os.path.join(app.config['UPLOAD'], filename))
        return send_from_directory(app.config['UPLOAD'], filename)
    return render_template('render.html')

#upload with redirect and url_for
UPLOAD_FOLDER = '/home/hieu/Flask/flask_dir/static/uploads/'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        file = request.files['file']
        filename = secure_filename(file.filename)
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        return redirect(url_for('display_file', name=filename))
    return render_template('upload.html')

#sau khi upload chuyển hướng đến trang hiển thị tệp
@app.route('/uploads/<name>')
def display_file(name):
    return send_from_directory(app.config["UPLOAD_FOLDER"], name)

if __name__ == '__main__':
    app.run(debug=True, port=9000)
